# My Portfolio

- list 1
- list 2
- list 3

This is a **bold** text

```javascript
let y = new Date().getFullYear()

document.querySelector('h1').innerHTML = y
console.log(y)
```
```html
<h1>hola</h1>
```

[Facebook](https://www.facebook.com)

![alt text](https://babaimandal.github.io/portfolio/images/ujjal-mondal-photo.png)https://babaimandal.github.io/portfolio/images/ujjal-mondal-photo.png)
